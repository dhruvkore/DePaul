var BarChartVis = function() {
    var newBC = {
            // data should have form [ {label: "", value: #}]
            drawBarChart: function(chart, data) {

            var margin = 30;
            var width = 120;
            var height = 300;

            var x = d3.scale.ordinal()
                .domain([0,1,2,3,4,5])
                .rangeBands([0,width]);
                
            var y = d3.scale.linear()
                .domain([0,100])
                .range([height,0]);

            chart.attr("width",width + 2*margin)
                .attr("height",height + 2*margin)
                .append("g")
                    .attr("transform","translate(" + margin + "," + margin + ")")
                .selectAll("rect")
                .data(data)
                .enter().append("rect")
                .attr("width",19)
                .attr("height",function(d) { return height - y(d); })
                .attr("x",function(d,i) { return x(i); })
                .attr("y",function(d) { return y(d); });

            var xAxis = d3.svg.axis()
                .scale(x)
                .orient("bottom")
                .ticks(1);

            var yAxis = d3.svg.axis()
                .scale(y)
                .orient("left")
                .ticks(5);

            chart.append("g")
                .attr("transform", "translate(" + margin + "," + (height+margin) + ")")
                .attr("class","axis")
                .call(xAxis);
                
            chart.append("g")
                .attr("transform", "translate(" + margin + "," + margin + ")")
                .attr("class","axis")
                .call(yAxis);
            }
        }
    
        return newBC;
    }